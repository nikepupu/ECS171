%% read data
data = xlsread('data2.xls');
data = data(:,4:55 );
x = data(:,1:46) ;
y = data(:,47:52);

rng(100)
index = randsample(1531,1531);


for i = 1: 46
  if max(x(:,i)) - min(x(:,i)) ~= 0
    x(:,i) = (x(:,i) - min(x(:,i)))/(max(x(:,i)) - min(x(:,i)));
  end
end

%% generate label
boundary = zeros(6,4);
for i = 1 : 6
  boundary(i,:) = quantile(y(:,i), [0.2 0.4 0.6 0.8]);
end

for i = 1 : 6
  a = y(:,i);
  low = (a < boundary(i,1));
  med1 = 2* (a >= boundary(i,1) & a <= boundary(i,2));
  med2 = 3* (a >= boundary(i,2) & a <= boundary(i,3));
  med3 = 4* (a >= boundary(i,3) & a <= boundary(i,4));
  high = 5 *(a > boundary(i,4) );
  y(:,i) = low + med1 + med2 + med3 + high;
end

%%
correct = [];
for i = 1 : 6
  totalcorrect = svm(y(:,i)', 5, x', index);
  correct = [correct totalcorrect/(50 * 150)];
end
correct
