function w = kernal(a, b)
  w = a' * b;
end